from pyscript.cli import app

app()
